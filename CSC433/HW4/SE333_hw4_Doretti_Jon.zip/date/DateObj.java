
public class DateObj {
	
	private int year;
	private int month;
	private int day;
	private int[] monthLengths = new int[] {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	
	public DateObj(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.day = day;
		validate();
	}


	public DateObj nextDate(){
		if (day < monthLengths[month - 1]){ // checks days if they are less than month
			day = day+1;
		}else if (day == monthLengths[month - 1]){// if days are equal to month check...
			day = 1; //change the day to 1 - no matter what it is the start of a new month
			if (month != 12){ // if it is not december...
				month = month + 1; // go to the next month
				
			}else{// if it is December
				month = 1; // change month to january
				year = year + 1;// and change the year as january is start to the year
			}	
		}
		DateObj dateObj = new DateObj(year,month,day); // creates a new dateobj with new values
		return dateObj;
	}

	@Override
	public String toString() {
		return String.format("Date[year: %d, month: %d, day: %d]", year, month, day);
	}

	private void validate() throws IllegalArgumentException {
		if (year % 4 == 0){
			monthLengths[1] = 29;//sets Feb to 29 as year % 4 == 0 is a leap year 
		}
		
		if (month > 12){ // there are only 12 months
			throw new IllegalArgumentException("Invalid month");
		}

		if(day > monthLengths[month - 1]){ //day can not be greater than value in monthLengths[]
			throw new IllegalArgumentException("Invalid date");
		}
	}

	

}
