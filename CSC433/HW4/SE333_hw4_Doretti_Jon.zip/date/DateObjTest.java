import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Test;

public class DateObjTest{
    @Test
    public void leapYear(){ //test dates in the past and leap years
        DateObj dateObj =  new DateObj(2020,2,28);
        dateObj.nextDate();

        String output = "Date[year: 2020, month: 2, day: 29]";
        Assert.assertEquals(output, dateObj.toString());
    }

    @Test
    public void diffMonthLen(){//test dates in the future, various lengths, and month changes
        DateObj dateObj = new DateObj(2023, 1, 29); //test date length 31 & month roll over
        dateObj.nextDate();
        dateObj.nextDate();
        dateObj.nextDate();

        String output = "Date[year: 2023, month: 2, day: 1]";
        Assert.assertEquals(output, dateObj.toString());

        DateObj dateObj2 = new DateObj(2024, 11, 28); //test date length 30 & month roll over
        dateObj2.nextDate();
        dateObj2.nextDate();
        dateObj2.nextDate();

        String output1 = "Date[year: 2024, month: 12, day: 1]";
        Assert.assertEquals(output1, dateObj2.toString());
    }

    @Test
    public void nextYear(){
        DateObj dateObj = new DateObj(2022, 12, 31);// last day of year
        dateObj.nextDate();

        String output = "Date[year: 2023, month: 1, day: 1]";// expected output
        Assert.assertEquals(output, dateObj.toString());
    }

    @Test
    public void throwsException(){
        try{
            DateObj dateObj = new DateObj(2021, 2, 29);// 2021 is not leap year
            fail("Exception should have occured");
        }catch (IllegalArgumentException e){
            assertEquals(e.getMessage(), "Invalid date");// should get exception
        }
    }

    @Test
    public void invalidMonth(){
        try{
            DateObj dateObj = new DateObj(2021, 13, 29);// 2021 is not leap year
            fail("Exception should have occured");
        }catch (IllegalArgumentException e){
            assertEquals(e.getMessage(), "Invalid month");// should get exception
        }
    }
}