import org.junit.*;
import static org.junit.Assert.*;

public class CartTest {
    @Test
    public void isCreated() {
        ShoppingCart cart = new ShoppingCart();

        Assert.assertEquals(0, cart.getItemCount());
    }

    @Test
    public void isEmpty() {
        ShoppingCart cart = new ShoppingCart();
        cart.empty();

        Assert.assertEquals(0, cart.getItemCount());

    }

    @Test
    public void isAdded() {
        ShoppingCart cart = new ShoppingCart();
        Product bread = new Product("Bread", 4.99);
        cart.addItem(bread);

        Assert.assertEquals(1, cart.getItemCount());
    }

    @Test
    public void isRemoved() {
        ShoppingCart cart = new ShoppingCart();

        Product bread = new Product("Bread", 4.99);
        Product milk = new Product("Milk", 7.99);

        cart.addItem(bread);
        cart.addItem(milk);

        cart.removeItem(bread);

        Assert.assertEquals(1, cart.getItemCount());

    }

}
